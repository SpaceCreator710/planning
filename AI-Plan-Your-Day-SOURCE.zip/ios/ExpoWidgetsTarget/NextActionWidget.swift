import WidgetKit
import SwiftUI
internal import ExpoWidgets

struct NextActionWidget: Widget {
  let name: String = "NextActionWidget"

  var body: some WidgetConfiguration {
    StaticConfiguration(kind: name, provider: WidgetsTimelineProvider(name: name)) { entry in
      WidgetsEntryView(entry: entry)
    }
    .configurationDisplayName("Next Action")
    .description("Shows the next link in your day chain.")
    .supportedFamilies([.systemSmall, .systemMedium, .accessoryCircular, .accessoryRectangular, .accessoryInline])
  }
}