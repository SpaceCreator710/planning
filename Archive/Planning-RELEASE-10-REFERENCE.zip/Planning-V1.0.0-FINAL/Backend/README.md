# AI Backend

This folder is deployed separately from the iOS client.

`netlify/functions/ai.mjs` is the protected server boundary used for planning, replanning, profile analysis, horizon planning, Coach actions and AI-generated subtasks.

## Environment variables

Configure provider credentials in the deployment environment, never in the iOS project. The client receives only the public backend base URL through `Config.xcconfig`.

Run the backend's included tests before deployment when changing request schemas or validation.
