import SwiftUI

struct GoalsView: View {
    @Environment(AppStore.self) private var store
    @State private var showingNew = false
    private var activeGoals: [Goal] { store.data.goals.filter { !$0.archived } }
    var body: some View {
        List {
            if activeGoals.isEmpty { ContentUnavailableView("No goals yet", systemImage: "target", description: Text("Create a goal and connect your daily plan to something that matters.")) }
            ForEach(activeGoals) { goal in NavigationLink { GoalDetailView(goalID: goal.id) } label: { VStack(alignment: .leading, spacing: 6) { HStack { Text(goal.title).font(.headline); Spacer(); Text("\(goal.progress)%").font(.subheadline).monospacedDigit() }; ProgressView(value: Double(goal.progress), total: 100); if !goal.why.isEmpty { Text(goal.why).font(.caption).foregroundStyle(.secondary).lineLimit(2) } } } }
        }
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("Goals").toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showingNew = true } label: { Image(systemName: "plus") }.accessibilityLabel("New goal") } }.sheet(isPresented: $showingNew) { NavigationStack { NewGoalView() } }
    }
}

private struct NewGoalView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""; @State private var why = ""; @State private var category: TaskCategory = .focus
    var body: some View { Form { TextField("Goal", text: $title); TextField("Why it matters", text: $why, axis: .vertical); Picker("Category", selection: $category) { ForEach(TaskCategory.allCases) { Text($0.rawValue.capitalized).tag($0) } } }
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("New Goal").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Save") { store.data.goals.append(Goal(title: title, why: why, category: category)); store.persist(); dismiss() }.disabled(title.isEmpty) } } }
}

private struct GoalDetailView: View {
    @Environment(AppStore.self) private var store
    let goalID: String
    @State private var milestone = ""
    private var index: Int? { store.data.goals.firstIndex { $0.id == goalID } }
    var body: some View {
        Group { if let index { @Bindable var store = store; Form { Section { TextField("Goal", text: $store.data.goals[index].title); TextField("Why", text: $store.data.goals[index].why, axis: .vertical); Slider(value: Binding(get: { Double(store.data.goals[index].progress) }, set: { store.data.goals[index].progress = Int($0); store.persist() }), in: 0...100, step: 1); Text("Progress · \(store.data.goals[index].progress)%") }
            Section("Milestones") { ForEach($store.data.goals[index].milestones) { $item in Toggle(item.title, isOn: $item.completed) }; HStack { TextField("Add milestone", text: $milestone); Button { guard !milestone.isEmpty else { return }; store.data.goals[index].milestones.append(GoalMilestone(title: milestone)); milestone = ""; store.persist() } label: { Image(systemName: "plus.circle.fill") }.accessibilityLabel("Add milestone") } }
            Section { Button("Archive goal", role: .destructive) { store.data.goals[index].archived = true; store.persist() } }
        } } else { ContentUnavailableView("Goal not found", systemImage: "exclamationmark.triangle") } }
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("Goal").onDisappear { store.persist() }
    }
}
