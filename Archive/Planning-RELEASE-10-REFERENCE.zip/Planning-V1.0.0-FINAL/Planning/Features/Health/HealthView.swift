import Foundation
import SwiftUI

struct HealthView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.colorScheme) private var scheme
    @State private var requesting = false
    @State private var mode: WellnessMode = .fitness
    @State private var connectionMessage: String?

    private enum WellnessMode: String, CaseIterable, Identifiable {
        case health = "Health"
        case fitness = "Fitness"
        var id: String { rawValue }
        var symbol: String { self == .health ? "heart.text.square.fill" : "figure.run.circle.fill" }
    }

    var body: some View {
        let p = AppPalette.resolve(settings: store.data.settings, scheme: scheme)
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 18) {
                modeSwitcher(palette: p)

                if store.data.settings.healthSyncEnabled {
                    if mode == .health { healthHome(palette: p) }
                    else { fitnessHome(palette: p) }

                    PremiumGlassCard(tint: p.accent.opacity(0.035)) {
                        Label {
                            Text("Health information stays on this device. Planning uses neutral summaries for scheduling and never treats them as a diagnosis.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        } icon: {
                            Image(systemName: "lock.shield.fill").foregroundStyle(p.accent)
                        }
                    }
                } else {
                    connectionCard(palette: p)
                }
            }
            .padding(16)
            .padding(.bottom, 110)
        }
        .appCanvas()
        .navigationTitle("Health & Fitness")
        .refreshable { await store.refreshHealthIfNeeded() }
        .task {
            if store.data.settings.healthSyncEnabled { await store.refreshHealthIfNeeded() }
        }
        .alert("Health connection", isPresented: Binding(
            get: { connectionMessage != nil },
            set: { if !$0 { connectionMessage = nil } }
        )) {
            Button("OK", role: .cancel) { connectionMessage = nil }
        } message: {
            Text(connectionMessage ?? "")
        }
    }

    private func modeSwitcher(palette p: AppPalette) -> some View {
        GlassEffectContainer(spacing: 8) {
            HStack(spacing: 8) {
                ForEach(WellnessMode.allCases) { item in
                    if item == mode {
                        modeButton(item)
                            .buttonStyle(.glassProminent)
                            .tint(p.accent)
                            .accessibilityAddTraits(.isSelected)
                    } else {
                        modeButton(item)
                            .buttonStyle(.glass)
                    }
                }
            }
        }
        .sensoryFeedback(.selection, trigger: mode)
    }

    private func modeButton(_ item: WellnessMode) -> some View {
        Button {
            withAnimation(.spring(duration: 0.34, bounce: 0.08)) { mode = item }
        } label: {
            Label(item.rawValue, systemImage: item.symbol)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
        }
    }

    private func connectionCard(palette p: AppPalette) -> some View {
        PremiumGlassCard(tint: p.accent.opacity(0.08)) {
            VStack(alignment: .leading, spacing: 13) {
                Image(systemName: "heart.text.square.fill")
                    .font(.largeTitle)
                    .foregroundStyle(p.accent)
                Text("Connect Health & Fitness")
                    .font(.title2.bold())
                Text("Choose the Health categories you want Planning to read. Activity, workouts and Apple Watch summaries appear here automatically after permission is granted.")
                    .foregroundStyle(p.secondary)
                Button {
                    connect()
                } label: {
                    if requesting {
                        ProgressView().controlSize(.small)
                    } else {
                        Label("Connect Health", systemImage: "link")
                    }
                }
                .buttonStyle(.glassProminent)
                .disabled(requesting)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    @ViewBuilder
    private func healthHome(palette p: AppPalette) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionLabel("Today", subtitle: lastUpdatedLabel)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                metric("Sleep", value: String(format: "%.1f h", store.healthSnapshot.sleepHours), icon: "bed.double.fill", palette: p)
                metric("Steps", value: store.healthSnapshot.steps.formatted(), icon: "figure.walk", palette: p)
                metric("Exercise", value: "\(store.healthSnapshot.exerciseMinutes) min", icon: "figure.run", palette: p)
                metric("Distance", value: String(format: "%.1f km", store.healthSnapshot.distanceKilometers), icon: "map.fill", palette: p)
            }
        }

        VStack(alignment: .leading, spacing: 10) {
            SectionLabel("Health categories", subtitle: "Every available HealthKit category is organized here.")
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(HealthDataSection.allCases) { section in
                    NavigationLink { HealthSectionDetailView(section: section) } label: {
                        VStack(alignment: .leading, spacing: 9) {
                            Image(systemName: section.symbol)
                                .font(.title3)
                                .foregroundStyle(p.accent)
                            Text(section.rawValue)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(p.text)
                                .lineLimit(2)
                            Text(sectionSummary(section))
                                .font(.caption2)
                                .foregroundStyle(p.secondary)
                                .lineLimit(1)
                        }
                        .frame(maxWidth: .infinity, minHeight: 104, alignment: .topLeading)
                        .padding(13)
                        .premiumGlassRounded(cornerRadius: 22, tint: p.accent.opacity(0.04), interactive: true)
                    }
                    .buttonStyle(.plain)
                }
            }
        }

        DisclosureGroup {
            VStack(spacing: 12) {
                capacityCard
                if let rhythm = InsightsEngine.bodyRhythm(profile: store.data.profile) { bodyRhythmCard(rhythm) }
                collisionCards
            }
            .padding(.top, 10)
        } label: {
            Label("Planning insights", systemImage: "sparkles")
                .font(.headline)
        }
        .padding(15)
        .premiumGlassRounded(cornerRadius: 23, tint: p.accent.opacity(0.045), interactive: true)
    }

    @ViewBuilder
    private func fitnessHome(palette p: AppPalette) -> some View {
        activityRingsCard(palette: p)

        VStack(alignment: .leading, spacing: 10) {
            SectionLabel("Fitness today", subtitle: "Synced from Apple Watch and HealthKit.")
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                metric("Workouts", value: store.healthSnapshot.workoutCount.formatted(), icon: "figure.mixed.cardio", palette: p)
                metric("Workout time", value: "\(store.healthSnapshot.workoutMinutes) min", icon: "timer", palette: p)
                metric("Stand", value: "\(store.healthSnapshot.standMinutes) min", icon: "figure.stand", palette: p)
                metric("Steps", value: store.healthSnapshot.steps.formatted(), icon: "shoeprints.fill", palette: p)
            }
        }

        VStack(alignment: .leading, spacing: 10) {
            SectionLabel("Recent workouts", subtitle: "The latest 30 days from HealthKit.")
            let workouts = store.healthSnapshot.recentWorkouts ?? []
            if workouts.isEmpty {
                PremiumGlassCard {
                    Label("No shared workouts yet", systemImage: "figure.run.circle")
                        .foregroundStyle(.secondary)
                }
            } else {
                ForEach(workouts.prefix(12)) { workout in
                    HStack(spacing: 12) {
                        Image(systemName: workout.symbol)
                            .font(.title3)
                            .foregroundStyle(p.accent)
                            .frame(width: 30)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(workout.title).font(.headline)
                            Text(workoutDate(workout.startedAt))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("\(workout.durationMinutes) min").font(.subheadline.weight(.semibold))
                            if let distance = workout.distanceKilometers {
                                Text(String(format: "%.1f km", distance)).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                    }
                    .padding(14)
                    .premiumGlassRounded(cornerRadius: 21, tint: p.accent.opacity(0.035), interactive: true)
                }
            }
        }

        PremiumGlassCard {
            Label {
                Text("Planning syncs the Activity Rings, goals, workouts and statistics Apple exposes through HealthKit. Fitness+ plans and private Fitness app preferences remain managed by Apple.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } icon: {
                Image(systemName: "checkmark.shield.fill").foregroundStyle(p.accent)
            }
        }
    }

    private func activityRingsCard(palette p: AppPalette) -> some View {
        let rings = store.healthSnapshot.fitnessRings ?? FitnessRingSnapshot()
        return PremiumGlassCard(tint: p.accent.opacity(0.075)) {
            HStack(spacing: 20) {
                ZStack {
                    ring(progress: rings.moveProgress, color: .pink, width: 13, inset: 0)
                    ring(progress: rings.exerciseProgress, color: .green, width: 11, inset: 17)
                    ring(progress: rings.standProgress, color: .cyan, width: 9, inset: 32)
                }
                .frame(width: 118, height: 118)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Activity Rings").font(.title3.bold())
                    ringLabel("Move", rings.moveProgress, .pink)
                    ringLabel("Exercise", rings.exerciseProgress, .green)
                    ringLabel("Stand", rings.standProgress, .cyan)
                    Text("Goals come from Apple Fitness when available.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
        }
    }

    private func ring(progress: Double, color: Color, width: CGFloat, inset: CGFloat) -> some View {
        ZStack {
            Circle().stroke(color.opacity(0.15), lineWidth: width)
            Circle()
                .trim(from: 0, to: min(1, max(0, progress)))
                .stroke(color, style: StrokeStyle(lineWidth: width, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(.spring(duration: 0.6, bounce: 0.08), value: progress)
        }
        .padding(inset)
    }

    private func ringLabel(_ title: String, _ progress: Double, _ color: Color) -> some View {
        HStack(spacing: 7) {
            Circle().fill(color).frame(width: 8, height: 8)
            Text(title).font(.caption.weight(.semibold))
            Spacer()
            Text("\(Int((progress * 100).rounded()))%")
                .font(.caption.weight(.bold).monospacedDigit())
        }
    }

    private func metric(_ title: String, value: String, icon: String, palette p: AppPalette) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: icon).font(.title3).foregroundStyle(p.accent)
            Text(value).font(.title3.bold()).monospacedDigit()
            Text(title).font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .premiumGlassRounded(cornerRadius: 22, tint: p.accent.opacity(0.04), interactive: true)
    }

    private var capacityCard: some View {
        let signal = InsightsEngine.capacity(from: store.healthSnapshot)
        return PremiumGlassCard {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel("Capacity Twin", subtitle: signal.summary)
                ProgressView(value: Double(signal.score), total: 100)
                Text("\(signal.score)% · suggested focus \(signal.suggestedFocusMinutes) min")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func bodyRhythmCard(_ rhythm: BodyRhythmSignal) -> some View {
        PremiumGlassCard {
            VStack(alignment: .leading, spacing: 8) {
                SectionLabel("Body Rhythm", subtitle: "Day \(rhythm.day) · \(rhythm.phase.rawValue.capitalized)")
                Text(rhythm.guidance).font(.subheadline).foregroundStyle(.secondary)
            }
        }
    }

    private var collisionCards: some View {
        let capacity = InsightsEngine.capacity(from: store.healthSnapshot)
        let collisions = InsightsEngine.scheduleCollisions(plan: store.activePlan, capacity: capacity)
        return Group {
            ForEach(collisions) { collision in
                PremiumGlassCard {
                    Label {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(collision.title).font(.headline)
                            Text(collision.detail).font(.caption).foregroundStyle(.secondary)
                        }
                    } icon: {
                        Image(systemName: collision.severity == .high ? "exclamationmark.triangle.fill" : "exclamationmark.circle.fill")
                    }
                }
            }
        }
    }

    private var lastUpdatedLabel: String {
        guard let date = ISO8601DateFormatter().date(from: store.healthSnapshot.lastUpdated) else { return "Synced from HealthKit" }
        return "Updated \(date.formatted(date: .omitted, time: .shortened))"
    }

    private func sectionSummary(_ section: HealthDataSection) -> String {
        let values = store.healthSnapshot.metrics ?? []
        let available = values.filter { $0.section == section && $0.value != nil }.count
        return available == 0 ? "Ready when shared" : "\(available) synced"
    }

    private func workoutDate(_ raw: String) -> String {
        guard let date = ISO8601DateFormatter().date(from: raw) else { return raw }
        return date.formatted(date: .abbreviated, time: .shortened)
    }

    private func connect() {
        guard !requesting else { return }
        requesting = true
        Task {
            let ok = await HealthService.shared.requestReadAccess()
            await MainActor.run {
                store.updateSettings {
                    $0.healthSyncEnabled = ok
                    $0.healthPlanningEnabled = ok
                }
                requesting = false
                if !ok { connectionMessage = "Health access was not granted. You can choose permissions later in iOS Settings." }
            }
            if ok { await store.refreshHealthIfNeeded() }
        }
    }
}

private struct HealthSectionDetailView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.colorScheme) private var scheme
    let section: HealthDataSection

    private var metrics: [HealthMetricSnapshot] {
        let actual = Dictionary(uniqueKeysWithValues: (store.healthSnapshot.metrics ?? []).map { ($0.id, $0) })
        return HealthService.catalog
            .filter { $0.section == section }
            .map { actual[$0.id] ?? $0 }
            .sorted { lhs, rhs in
                if (lhs.value != nil) != (rhs.value != nil) { return lhs.value != nil }
                return lhs.title < rhs.title
            }
    }

    var body: some View {
        let p = AppPalette.resolve(settings: store.data.settings, scheme: scheme)
        ScrollView {
            LazyVStack(spacing: 11) {
                PremiumGlassCard(tint: p.accent.opacity(0.07)) {
                    HStack(spacing: 13) {
                        Image(systemName: section.symbol)
                            .font(.title2)
                            .foregroundStyle(p.accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(section.rawValue).font(.title3.bold())
                            Text("Only categories authorized in Apple Health show values.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                }

                ForEach(metrics) { metric in
                    HStack(spacing: 13) {
                        Image(systemName: metric.symbol)
                            .font(.headline)
                            .foregroundStyle(metric.value == nil ? p.tertiary : p.accent)
                            .frame(width: 28)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(metric.title).font(.headline)
                            if let raw = metric.recordedAt, let date = ISO8601DateFormatter().date(from: raw) {
                                Text(date.formatted(date: .abbreviated, time: .shortened))
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            } else {
                                Text(metric.value == nil ? "No shared data" : "Today")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        Text(formatted(metric))
                            .font(.subheadline.weight(.semibold).monospacedDigit())
                            .foregroundStyle(metric.value == nil ? p.tertiary : p.text)
                    }
                    .padding(14)
                    .premiumGlassRounded(cornerRadius: 21, tint: p.accent.opacity(0.035), interactive: true)
                }
            }
            .padding(16)
            .padding(.bottom, 90)
        }
        .appCanvas()
        .navigationTitle(section.rawValue)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func formatted(_ metric: HealthMetricSnapshot) -> String {
        guard let value = metric.value else { return "—" }
        let number = String(format: "%.*f", metric.precision, value)
        return metric.unit.isEmpty ? number : "\(number) \(metric.unit)"
    }
}
