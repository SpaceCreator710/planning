import SwiftUI

struct InboxView: View {
    @Environment(AppStore.self) private var store
    @State private var title = ""

    var body: some View {
        List {
            Section("Quick capture") {
                HStack(spacing: 10) {
                    TextField("Capture something", text: $title)
                        .submitLabel(.done)
                        .onSubmit(add)
                    Button { add() } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                    .accessibilityLabel("Add to inbox")
                    .disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }

            if store.data.inbox.isEmpty {
                ContentUnavailableView(
                    "Inbox clear",
                    systemImage: "tray",
                    description: Text("Capture an idea here when you do not want to decide when it belongs yet.")
                )
            } else {
                Section("Unplanned") {
                    ForEach(store.data.inbox) { item in
                        HStack(spacing: 12) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(item.title)
                                    .font(.headline)
                                if let note = item.note, !note.isEmpty {
                                    Text(note)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(2)
                                }
                            }
                            Spacer()
                            Button("Plan") { store.planInbox(item) }
                                .buttonStyle(.glass)
                        }
                        .draggable("inbox:\(item.id)")
                    }
                    .onDelete { offsets in
                        let ids = offsets.map { store.data.inbox[$0].id }
                        ids.forEach(store.deleteInbox)
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("Inbox")
        .dropDestination(for: String.self) { items, _ in
            guard let payload = items.first, payload.hasPrefix("task:") else { return false }
            store.moveTaskToInbox(String(payload.dropFirst(5)))
            return true
        }
    }

    private func add() {
        let value = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        store.addInbox(value)
        title = ""
    }
}
