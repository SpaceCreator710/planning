import SwiftUI

struct IntegrationsView: View {
    @Environment(AppStore.self) private var store
    @State private var calendarWorking = false
    @State private var healthWorking = false
    @State private var integrationError: String?

    var body: some View {
        List {
            if store.hasAccess(.appleIntegrations) {
                Section("Apple") {
                    integration("Calendar", "calendar", store.data.settings.calendarSyncEnabled, working: calendarWorking) {
                        connectCalendar()
                    }
                    integration("Health", "heart.fill", store.data.settings.healthSyncEnabled, working: healthWorking) {
                        connectHealth()
                    }
                }

                Section("Automation") {
                    Toggle("Auto-replan after calendar changes", isOn: Binding(
                        get: { store.data.settings.autoCalendarReplan },
                        set: { value in store.updateSettings { $0.autoCalendarReplan = value } }
                    ))
                    Toggle("Use capacity in planning", isOn: Binding(
                        get: { store.data.settings.healthPlanningEnabled },
                        set: { value in store.updateSettings { $0.healthPlanningEnabled = value } }
                    ))
                }
            } else {
                Section("Apple integrations") {
                    Label("Calendar and Health planning are included with Pro.", systemImage: "lock.fill")
                        .foregroundStyle(.secondary)
                    NavigationLink { PaywallView() } label: {
                        Label("See Pro", systemImage: "sparkles")
                    }
                }
            }

            Section {
                Text("Widgets, Live Activities and Control Center actions are native extension targets in this SwiftUI project and share state through the app group.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("Integrations")
        .alert("Integration couldn't connect", isPresented: Binding(
            get: { integrationError != nil },
            set: { if !$0 { integrationError = nil } }
        )) {
            Button("OK", role: .cancel) { integrationError = nil }
        } message: {
            Text(integrationError ?? "Try again later.")
        }
    }

    @ViewBuilder
    private func integration(
        _ title: String,
        _ icon: String,
        _ connected: Bool,
        working: Bool,
        action: @escaping () -> Void
    ) -> some View {
        HStack {
            Label(title, systemImage: icon)
            Spacer()
            if connected {
                Label("Connected", systemImage: "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundStyle(.green)
            } else if working {
                ProgressView()
                    .controlSize(.small)
                    .accessibilityLabel("Connecting \(title)")
            } else {
                Button("Connect", action: action)
                    .buttonStyle(.glass)
            }
        }
    }

    private func connectCalendar() {
        guard !calendarWorking else { return }
        calendarWorking = true
        integrationError = nil

        Task {
            let ok = await CalendarService.shared.requestCalendarAccess()
            await MainActor.run {
                store.updateSettings { $0.calendarSyncEnabled = ok }
            }

            if ok {
                let start = Calendar.current.date(byAdding: .day, value: -14, to: .now) ?? .now
                let end = Calendar.current.date(byAdding: .day, value: 60, to: .now) ?? .now
                let tasks = await CalendarService.shared.calendarTasks(from: start, to: end)
                await MainActor.run {
                    for task in tasks { store.updateTask(task) }
                    calendarWorking = false
                }
            } else {
                await MainActor.run {
                    calendarWorking = false
                    integrationError = "Calendar access was not granted. You can change access later in iOS Settings."
                }
            }
        }
    }

    private func connectHealth() {
        guard !healthWorking else { return }
        healthWorking = true
        integrationError = nil

        Task {
            let ok = await HealthService.shared.requestReadAccess()
            await MainActor.run {
                store.updateSettings {
                    $0.healthSyncEnabled = ok
                    $0.healthPlanningEnabled = ok
                }
                healthWorking = false
                if !ok {
                    integrationError = "Health access was not granted. You can change access later in iOS Settings."
                }
            }
            if ok { await store.refreshHealthIfNeeded() }
        }
    }
}
