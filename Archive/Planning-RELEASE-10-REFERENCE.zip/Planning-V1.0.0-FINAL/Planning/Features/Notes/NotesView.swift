import SwiftUI

struct NotesView: View {
    @Environment(AppStore.self) private var store
    @State private var search = ""
    @State private var editing: AppNote?
    @State private var newNote = false

    private var filtered: [AppNote] {
        guard !search.isEmpty else { return store.data.notes.sorted { $0.updatedAt > $1.updatedAt } }
        return store.data.notes.filter { $0.title.localizedCaseInsensitiveContains(search) || $0.body.localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        List {
            Section {
                NavigationLink { InboxView() } label: {
                    HStack {
                        Label("Inbox", systemImage: "tray.full.fill").font(.headline)
                        Spacer()
                        Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
                    }
                    .padding(14)
                    .premiumGlassRounded(cornerRadius: 22, interactive: true)
                }
                .buttonStyle(.plain)
                .listRowBackground(Color.clear)
                .listRowSeparator(.hidden)
            }
            Section("Notes") {
                if filtered.isEmpty { ContentUnavailableView("No notes", systemImage: "note.text", description: Text("Capture an idea, then turn it into a task when you're ready.")) }
                ForEach(filtered) { note in
                    Button { editing = note } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(note.title.isEmpty ? "Untitled" : note.title).font(.headline).foregroundStyle(.primary)
                            Text(note.body).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(14)
                        .premiumGlassRounded(cornerRadius: 22, interactive: true)
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
                }
                .onDelete { offsets in offsets.map { filtered[$0].id }.forEach(store.deleteNote) }
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("Notes").searchable(text: $search)
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { newNote = true } label: { Image(systemName: "square.and.pencil") }.accessibilityLabel("New note") } }
        .sheet(item: $editing) { note in NavigationStack { NoteEditorView(note: note) } }
        .sheet(isPresented: $newNote) { NavigationStack { NoteEditorView(note: AppNote(title: "")) } }
    }
}

private struct NoteEditorView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State var note: AppNote
    var body: some View {
        Form { TextField("Title", text: $note.title).font(.title2.bold()); TextEditor(text: $note.body).frame(minHeight: 260); Section { Button("Turn into task", systemImage: "checklist") { store.addTask(PlanEngine.manualTask(title: note.title.isEmpty ? note.body.split(separator: "\n").first.map(String.init) ?? "Note" : note.title, date: store.selectedDate)) } } }
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("Note").navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Save") { note.updatedAt = ISO8601DateFormatter().string(from: .now); store.saveNote(note); dismiss() } } }
    }
}
