import StoreKit
import SwiftUI

struct PaywallView: View {
    @Environment(AppStore.self) private var store
    @State private var products: [Product] = []
    @State private var purchasing: String?
    @State private var statusMessage: String?

    private let freeFeatures = [
        "Unlimited tasks, subtasks, Notes and Inbox",
        "Workspace pages/wiki, spaces, projects, 9 database views including Map, forms, charts, backlinks, Canvas/Graph and templates",
        "Web Clipper, Read Later, comments, version history, sites/presentation, Markdown/JSON import-export, command palette and time tracking",
        "Automations, meeting action notes, scheduling links, Smart Meetings, Focus Time and Weekly Autopilot",
        "23 Timeline tools available manually across the supported Day/Week timeline surfaces",
        "Horizontal Day + Horizontal Week timelines, smart task icons, widgets and Live Activities",
        "Basic reminders, themes and iCloud/local-first data",
        "Planning AI Agent + Custom Agent runs · up to 12 AI requests per day"
    ]

    private let proFeatures = [
        "Everything in Free",
        "Vertical + Orbit Day and Vertical Week timelines",
        "Time Machine + Magnetic Compress + full automatic Planning Intelligence suite",
        "Workspace Agent with app-wide safe actions + School AI + General AI + unlimited AI/custom-agent runs",
        "Recurring tasks and multiple/custom alerts",
        "Calendar + Health integrations",
        "Reality Replan + Horizon Planner",
        "Premium appearance, HSL colors and alternate app icons"
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                VStack(spacing: 8) {
                    Image(systemName: "crown.fill")
                        .font(.system(size: 44))
                    Text("Planning Pro")
                        .font(.largeTitle.bold())
                    Text("Keep the essentials generous. Unlock the full timeline, deeper automation and every AI mode when you want more.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 18)

                featureCard(
                    title: "Free",
                    badge: store.data.subscription.isPro ? "Included" : "Current",
                    features: freeFeatures
                )

                VStack(alignment: .leading, spacing: 10) {
                    Text("Pro")
                        .font(.title2.bold())
                    Text("Same Pro access with monthly or yearly billing.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    purchaseRow(kind: .monthly)
                    purchaseRow(kind: .yearly, badge: "Best value")
                }
                .padding(16)
                .premiumGlassRounded(cornerRadius: 24, tint: .accentColor.opacity(0.08), interactive: true)

                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Lifetime")
                            .font(.title2.bold())
                        Spacer()
                        Text("One purchase")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    Text("Planning Pro forever. No recurring payment.")
                        .foregroundStyle(.secondary)
                    purchaseRow(kind: .lifetime)
                }
                .padding(16)
                .premiumGlassRounded(cornerRadius: 24, tint: .accentColor.opacity(0.08), interactive: true)

                featureCard(title: "Everything in Pro", badge: nil, features: proFeatures)

                Button("Restore purchases") {
                    Task {
                        try? await StoreKit.AppStore.sync()
                        await refreshTier()
                        statusMessage = "Purchases restored."
                    }
                }
                .buttonStyle(.glass)

                Text("Prices shown are the planned US reference prices. The App Store supplies the final localized price in each storefront.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                if let statusMessage {
                    Text(statusMessage)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(16)
        }
        .appCanvas()
        .navigationTitle("Subscription")
        .task {
            await SubscriptionService.shared.loadProducts()
            products = SubscriptionService.shared.products
            await refreshTier()
        }
    }

    @ViewBuilder
    private func purchaseRow(kind: PlanningProductKind, badge: String? = nil) -> some View {
        let product = products.first(where: { $0.id == kind.productID })
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 7) {
                    Text(kind.title)
                        .font(.headline)
                    if let badge {
                        Text(badge.uppercased())
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .padding(.horizontal, 7)
                            .padding(.vertical, 3)
                            .premiumGlassCapsule(tint: .accentColor.opacity(0.10), interactive: true)
                    }
                }
                Text(product?.displayPrice ?? kind.referencePrice)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if let product {
                Button(purchasing == product.id ? "Processing…" : "Choose") {
                    purchasing = product.id
                    Task {
                        let ok = await SubscriptionService.shared.purchase(product)
                        await refreshTier()
                        purchasing = nil
                        statusMessage = ok ? "Planning Pro unlocked." : "Purchase was not completed."
                    }
                }
                .buttonStyle(.glassProminent)
                .disabled(purchasing != nil)
            } else {
                Image(systemName: "appstore")
                    .foregroundStyle(.secondary)
                    .accessibilityLabel("App Store product")
            }
        }
        .padding(12)
        .premiumGlassRounded(cornerRadius: 18, tint: nil, interactive: true)
    }

    private func featureCard(title: String, badge: String?, features: [String]) -> some View {
        MatteCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text(title).font(.title2.bold())
                    Spacer()
                    if let badge { Text(badge).font(.headline).foregroundStyle(.secondary) }
                }
                DisclosureGroup("\(features.count) included features") {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(features, id: \.self) { feature in
                            Label(feature, systemImage: "checkmark.circle.fill")
                                .font(.subheadline)
                        }
                    }
                    .padding(.top, 8)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func refreshTier() async {
        await store.refreshSubscriptionTier()
    }
}
