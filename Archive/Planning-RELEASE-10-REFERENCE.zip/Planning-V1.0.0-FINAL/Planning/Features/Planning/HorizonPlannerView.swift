import SwiftUI

struct HorizonPlannerView: View {
    @Environment(AppStore.self) private var store
    @State private var horizon: PlanningHorizon = .week
    @State private var objective = ""
    @State private var building = false
    var body: some View {
        Group {
            if store.hasAccess(.horizonPlanner) {
                List {
                    Section { Picker("Horizon", selection: $horizon) { ForEach(PlanningHorizon.allCases) { Text($0.rawValue.capitalized).tag($0) } }.pickerStyle(.segmented); TextField("What outcome do you want?", text: $objective, axis: .vertical); Button("Build roadmap", systemImage: "sparkles") { build() }.buttonStyle(.glassProminent).disabled(objective.isEmpty || building) }
                    Section("Roadmaps") { ForEach(store.data.horizonPlans.reversed()) { plan in VStack(alignment: .leading, spacing: 6) { Text(plan.title).font(.headline); Text(plan.summary).font(.subheadline).foregroundStyle(.secondary); ForEach(plan.checkpoints) { cp in VStack(alignment: .leading, spacing: 3) { Text(cp.label).font(.subheadline.bold()); Text(cp.outcome).font(.caption); ForEach(cp.actions, id: \.self) { Text("• \($0)").font(.caption).foregroundStyle(.secondary) } }.padding(.top, 4) } }.padding(.vertical, 6) } }
                }
                .scrollContentBackground(.hidden)
            } else {
                ContentUnavailableView { Label("Horizon Planner is Pro", systemImage: "map.fill") } description: { Text("Turn a week, month or year objective into an AI roadmap with checkpoints.") } actions: { NavigationLink("See Pro") { PaywallView() }.buttonStyle(.glassProminent) }
                    .padding()
            }
        }
        .appCanvas()
        .navigationTitle("Horizon Planner")
    }
    private func build() {
        guard store.hasAccess(.horizonPlanner), !objective.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        building = true
        let requestedObjective = objective
        let requestedHorizon = horizon
        Task {
            let aiPlan = await AIService.shared.buildHorizon(objective: requestedObjective, horizon: requestedHorizon, context: store.data)
            let fallbackCheckpoints = [
                HorizonCheckpoint(label: "Start", outcome: "Make the first measurable move", actions: ["Define the next action", "Reserve time for it"]),
                HorizonCheckpoint(label: "Middle", outcome: "Check progress and remove friction", actions: ["Review what changed", "Adjust the plan"]),
                HorizonCheckpoint(label: "Finish", outcome: "Close the loop", actions: ["Complete the outcome", "Review what worked"])
            ]
            await MainActor.run {
                let plan = aiPlan ?? HorizonPlan(
                    horizon: requestedHorizon,
                    objective: requestedObjective,
                    title: requestedObjective,
                    summary: "A focused \(requestedHorizon.rawValue) roadmap built around one clear outcome.",
                    checkpoints: fallbackCheckpoints
                )
                store.data.horizonPlans.insert(plan, at: 0)
                store.persist()
                objective = ""
                building = false
            }
        }
    }
}
