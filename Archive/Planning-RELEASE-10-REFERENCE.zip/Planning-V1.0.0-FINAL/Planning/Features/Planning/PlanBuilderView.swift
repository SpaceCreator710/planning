import SwiftUI

struct PlanBuilderView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var brainDump = ""
    @State private var mustWin = ""
    @State private var fixed = ""
    @State private var energy = 3
    @State private var style: PlanStyle = .realistic
    @State private var isBuilding = false

    var body: some View {
        Form {
            Section("What needs to happen?") { TextField("Tasks, ideas, obligations…", text: $brainDump, axis: .vertical).lineLimit(5...12); TextField("One must-win result", text: $mustWin); TextField("Fixed commitments", text: $fixed, axis: .vertical).lineLimit(2...5) }
            Section("Reality") { Stepper("Energy · \(energy)/5", value: $energy, in: 1...5); Picker("Plan style", selection: $style) { Text("Full").tag(PlanStyle.full); Text("Realistic").tag(PlanStyle.realistic); Text("Minimum").tag(PlanStyle.minimum) }.pickerStyle(.segmented) }
            Section { Button { build() } label: { HStack { Spacer(); if isBuilding { ProgressView() } else { Label("Build my day", systemImage: "sparkles") }; Spacer() } }.disabled(isBuilding || (brainDump.isEmpty && mustWin.isEmpty)) }
        }
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("AI Planner")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        .onAppear { fixed = store.data.profile.fixedCommitments }
    }
    private func build() { isBuilding = true; Task { await store.buildPlan(PlanBuildInput(brainDump: brainDump, mustWin: mustWin, fixedCommitments: fixed, energy: energy, style: style, plannerMode: .dayChain)); await MainActor.run { isBuilding = false; dismiss() } } }
}
