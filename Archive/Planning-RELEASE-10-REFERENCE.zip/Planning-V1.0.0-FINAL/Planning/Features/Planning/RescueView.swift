import SwiftUI

struct RescueView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var reason = "distracted"
    @State private var energy = 2
    @State private var minutes = 60
    @State private var working = false
    var body: some View {
        Group {
            if store.hasAccess(.advancedReplan) {
                Form {
                    Section("What changed?") { Picker("Reason", selection: $reason) { Text("Overslept").tag("overslept"); Text("Distracted").tag("distracted"); Text("Low energy").tag("low-energy"); Text("Task too big").tag("task-too-big"); Text("Unexpected event").tag("unexpected") }; Stepper("Energy · \(energy)/5", value: $energy, in: 1...5); Picker("Time left", selection: $minutes) { Text("10 min").tag(10); Text("30 min").tag(30); Text("1 hour").tag(60); Text("2 hours").tag(120) } }
                    Section { Button("Repair my plan", systemImage: "arrow.triangle.2.circlepath") { working = true; Task { await store.rescue(reason: reason, energy: energy, minutes: minutes); await MainActor.run { working = false; dismiss() } } }.disabled(working) }
                }
                .scrollContentBackground(.hidden)
            } else {
                ContentUnavailableView { Label("Reality Replan is Pro", systemImage: "arrow.triangle.2.circlepath") } description: { Text("Rebuild a disrupted day around what is still realistic.") } actions: { NavigationLink("See Pro") { PaywallView() }.buttonStyle(.glassProminent) }
                    .padding()
            }
        }
        .appCanvas()
        .navigationTitle("Reality Replan").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
    }
}
