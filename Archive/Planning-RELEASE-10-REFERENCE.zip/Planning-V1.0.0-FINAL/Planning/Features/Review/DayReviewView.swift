import SwiftUI

struct DayReviewView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var score = 70.0
    @State private var wins = ""
    @State private var blocker = ""
    @State private var lesson = ""
    @State private var mood = 3
    @State private var loaded = false

    var body: some View {
        Form {
            Section("How did today go?") {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Day score")
                        Spacer()
                        Text("\(Int(score))%")
                            .bold()
                            .monospacedDigit()
                    }
                    Slider(value: $score, in: 0...100, step: 5)
                }
                Stepper("Energy · \(mood)/5", value: $mood, in: 1...5)
            }

            Section("Reflection") {
                TextField("Wins, one per line", text: $wins, axis: .vertical)
                    .lineLimit(2...6)
                TextField("Main blocker", text: $blocker, axis: .vertical)
                    .lineLimit(1...4)
                TextField("Lesson for tomorrow", text: $lesson, axis: .vertical)
                    .lineLimit(2...6)
            }

            Section {
                Button("Save review", systemImage: "checkmark") { save() }
                    .buttonStyle(.glassProminent)
            }
        }
        .scrollContentBackground(.hidden)
        .appCanvas()
        .navigationTitle("Day Review")
        .task { loadExistingReview() }
    }

    private func loadExistingReview() {
        guard !loaded else { return }
        loaded = true
        guard let review = store.data.reviews.last(where: { $0.date == DateKey.today }) else { return }
        score = Double(review.score)
        wins = review.wins.joined(separator: "\n")
        blocker = review.blocker ?? ""
        lesson = review.lesson ?? ""
        mood = review.mood
    }

    private func save() {
        let review = DailyReview(
            date: DateKey.today,
            score: Int(score),
            wins: wins.split(separator: "\n").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty },
            blocker: normalized(blocker),
            lesson: normalized(lesson),
            mood: mood
        )
        if let index = store.data.reviews.lastIndex(where: { $0.date == DateKey.today }) {
            store.data.reviews[index] = review
        } else {
            store.data.reviews.append(review)
        }
        store.record("review-saved", DateKey.today)
        store.persist()
        dismiss()
    }

    private func normalized(_ value: String) -> String? {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }
}
