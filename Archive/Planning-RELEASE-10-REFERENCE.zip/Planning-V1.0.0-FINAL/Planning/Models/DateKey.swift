import Foundation

enum DateKey {
    static let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    static var today: String { formatter.string(from: .now) }
    static func string(_ date: Date) -> String { formatter.string(from: date) }
    static func date(_ key: String) -> Date? { formatter.date(from: key) }
    static func startOfDay(_ key: String) -> Date { date(key) ?? Calendar.current.startOfDay(for: .now) }
}

enum TimeMath {
    static func minutes(_ time: String?) -> Int? {
        guard let time else { return nil }
        let parts = time.split(separator: ":").compactMap { Int($0) }
        guard parts.count >= 2 else { return nil }
        return parts[0] * 60 + parts[1]
    }
    static func string(_ minutes: Int) -> String {
        let bounded = max(0, min(1439, minutes))
        return String(format: "%02d:%02d", bounded / 60, bounded % 60)
    }
    static var nowMinutes: Int {
        let c = Calendar.current.dateComponents([.hour, .minute], from: .now)
        return (c.hour ?? 0) * 60 + (c.minute ?? 0)
    }
}


enum TaskTimelineOrder {
    static func sortMinute(_ task: PlannerTask) -> Int {
        if task.allDay == true { return -1 }
        if let minute = TimeMath.minutes(task.startTime) { return minute }
        return 2_000
    }

    static func less(_ lhs: PlannerTask, _ rhs: PlannerTask) -> Bool {
        let left = sortMinute(lhs)
        let right = sortMinute(rhs)
        if left != right { return left < right }

        let leftEnd = TimeMath.minutes(lhs.endTime) ?? left + max(1, lhs.durationMinutes)
        let rightEnd = TimeMath.minutes(rhs.endTime) ?? right + max(1, rhs.durationMinutes)
        if leftEnd != rightEnd { return leftEnd < rightEnd }

        if lhs.priority != rhs.priority { return lhs.priority > rhs.priority }
        if lhs.title != rhs.title { return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending }
        return lhs.id < rhs.id
    }

    static func sorted(_ tasks: [PlannerTask]) -> [PlannerTask] {
        tasks.sorted(by: less)
    }
}

enum TimelineDateMath {
    static func startOfWeek(containing date: Date, calendar: Calendar = .current) -> Date {
        let start = calendar.startOfDay(for: date)
        let weekday = calendar.component(.weekday, from: start)
        let mondayOffset = (weekday + 5) % 7
        return calendar.date(byAdding: .day, value: -mondayOffset, to: start) ?? start
    }

    static func shifted(_ date: Date, days: Int, calendar: Calendar = .current) -> Date {
        calendar.date(byAdding: .day, value: days, to: date) ?? date
    }
}
