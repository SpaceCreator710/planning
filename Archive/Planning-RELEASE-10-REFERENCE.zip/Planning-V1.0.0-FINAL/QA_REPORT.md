# Planning 1.0.0 — QA report

Audit date: 2026-08-20

## Passed in the available environment

- Swift parser pass across app, widget, share-extension and shared Swift sources.
- Core regression tests pass.
- Netlify AI server boundary tests pass.
- `Planning.xcodeproj/project.pbxproj`, all Info.plists, entitlements and privacy manifests pass `plutil -lint`.
- Main product/target/scheme are named `Planning`.
- User-facing provider/API-key credential input is absent from the client source.
- Provider inference is server-only; the iOS app uses `AI_API_BASE_URL`.
- Account and monetization flows are explicitly disabled by default with `ACCOUNTS_ENABLED = NO` and `SUBSCRIPTIONS_ENABLED = NO`.
- With subscriptions disabled, feature access stays unlocked and the subscription screen is absent from normal navigation.

## Environment limitation

This environment is Linux and does not contain Xcode or the iOS SDK. It therefore cannot perform the decisive full SwiftUI type-check/link, signing, simulator/device launch, Apple entitlement/runtime, TestFlight, StoreKit sandbox, WidgetKit/ActivityKit, EventKit/HealthKit, CloudKit, accessibility or performance checks.

The repository is code-audited; the signed device checklist remains mandatory before an App Store submission.
