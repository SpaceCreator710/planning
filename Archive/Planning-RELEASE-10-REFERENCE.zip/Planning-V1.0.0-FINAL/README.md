# Planning 1.0.0

Planning is a native SwiftUI planner built around a live, interactive timeline that treats the day as something the user can see, touch and reshape in real time.

## Product status

The repository is prepared as the Planning 1.0.0 code release. The main app product/target is named `Planning`, the Home Screen display name is `Planning`, the share extension is `Save to Planning`, and the widget display name is `Planning Widgets`.

The iOS client no longer contains a user-entered AI provider credential flow. AI requests go through the protected server boundary in `Backend/`; provider credentials belong only in the deployment environment. Local deterministic planning remains available when that service is temporarily offline.

Registration and monetization are intentionally disabled behind explicit release flags until they are launched later. `ACCOUNTS_ENABLED = NO` removes account/registration UI from the current product. With `SUBSCRIPTIONS_ENABLED = NO`, product features remain unlocked and paywall UI stays out of the normal product flow.

## Core product

- Live Day Timeline and seven-chain Week Timeline.
- NOW state, NOW Lens, semantic zoom, detail zoom and Time Machine.
- Flow Shift, Push The Day, Ghost Future, Reality Layer, Smart Gaps/Open Space, collision handling and buffer nodes.
- Tasks, subtasks, recurrence, alerts, duplicate/move/inbox operations and rich task appearance.
- AI planning, AI Coach, AI-generated subtasks, Reality Replan and Horizon Planner with deterministic local fallbacks.
- Focus sessions, goals, progress, day review, notes, inbox, AI memory and capacity insights.
- Calendar and Health integrations.
- Widgets, Live Activities, Control Center/App Intent actions, Siri shortcuts and Share Extension.
- Local persistence plus private CloudKit sync; optional account/cloud boundary can be enabled later.

## Native Apple stack

- Swift 6 + SwiftUI
- SwiftData + CloudKit
- WidgetKit + ActivityKit + App Intents
- EventKit, HealthKit, UserNotifications
- StoreKit 2 (gated until monetization is enabled)
- Supabase auth/snapshot support (hidden until configured)
- Netlify server boundary for built-in AI

## Open and run

1. Open `Planning.xcodeproj` in Xcode 26+.
2. Select the `Planning` scheme/target.
3. Configure your Apple Developer team and the existing App Group/iCloud capabilities.
4. For real built-in AI, deploy `Backend/`, place the provider credential in server environment variables, and put only the public server URL in `Config.xcconfig` as `AI_API_BASE_URL`.
5. Build on Simulator, then validate Apple-framework features on a signed physical device.

See `SETUP_XCODE.md`, `RELEASE_SERVER_SETUP.md`, and `FINAL_PRODUCT_AUDIT.md`.

## Security

Provider secrets are never intended to be stored in the iOS bundle or entered by end users. Internal legacy bundle/app-group identifiers are intentionally retained where changing them would affect existing provisioning or data continuity; they are not product branding.
